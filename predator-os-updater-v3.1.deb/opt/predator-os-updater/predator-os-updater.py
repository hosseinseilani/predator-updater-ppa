import sys
import os 
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel, QRadioButton, QPushButton

class PredatorUpdaterApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Predator-OS Updater")
        self.setGeometry(100, 100, 400, 300)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout()

        # Row 1: Update
        update_label = QLabel("Update:sources.list")
        self.update_apt_radio = QRadioButton("apt")
        self.update_nala_radio = QRadioButton("nala")
        self.update_aptitude_radio = QRadioButton("aptitude")
        self.update_button = QPushButton("Update")
        self.update_button.clicked.connect(self.run_update_command)

        # Add widgets to layout
        layout.addWidget(update_label)
        layout.addWidget(self.update_apt_radio)
        layout.addWidget(self.update_nala_radio)
        layout.addWidget(self.update_aptitude_radio)
        layout.addWidget(self.update_button)

        # Row 2: Upgrade
        upgrade_label = QLabel("Upgrade:packages")
        self.upgrade_apt_radio = QRadioButton("apt")
        self.upgrade_nala_radio = QRadioButton("nala")
        self.upgrade_aptitude_radio = QRadioButton("aptitude")
        self.upgrade_button = QPushButton("Upgrade")
        self.upgrade_button.clicked.connect(self.run_upgrade_command)

        # Add widgets to layout
        layout.addWidget(upgrade_label)
        layout.addWidget(self.upgrade_apt_radio)
        layout.addWidget(self.upgrade_nala_radio)
        layout.addWidget(self.upgrade_aptitude_radio)
        layout.addWidget(self.upgrade_button)

        # Row 3: Apps
        apps_label = QLabel("Run Package Manager:")
        self.apps_discover_radio = QRadioButton("discover")
        self.apps_synaptic_radio = QRadioButton("synaptic")
        self.apps_button = QPushButton("Run App")
        self.apps_button.clicked.connect(self.run_app_command)

        # Add widgets to layout
        layout.addWidget(apps_label)
        layout.addWidget(self.apps_discover_radio)
        layout.addWidget(self.apps_synaptic_radio)
        layout.addWidget(self.apps_button)

        # Row 4: Updater
        updater_label = QLabel("Upgrade predator-os to last version:")
        self.updater_yes_radio = QRadioButton("yes")
        self.updater_no_radio = QRadioButton("no")
        self.updater_button = QPushButton("Upgrade to Last Version")
        self.updater_button.clicked.connect(self.run_updater_command)

        # Add widgets to layout
        layout.addWidget(updater_label)
        layout.addWidget(self.updater_yes_radio)
        layout.addWidget(self.updater_no_radio)
        layout.addWidget(self.updater_button)

        central_widget.setLayout(layout)

    def run_update_command(self):
        if self.update_apt_radio.isChecked():
            os.system("apt update -y")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "updating is finished"')
            os.system('echo')
        elif self.update_nala_radio.isChecked():
            os.system("nala update")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "updating is finished"')
            os.system('echo')
        elif self.update_aptitude_radio.isChecked():
            os.system("aptitude update")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "updating is finished"')
            os.system('echo')
        
    def run_upgrade_command(self):
        if self.upgrade_apt_radio.isChecked():
            os.system("apt dist-upgrade -y")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "Upgrading is finished"')
            os.system('echo')
        
        elif self.upgrade_nala_radio.isChecked():
            os.system("nala upgrade")
            os.system("apt dist-upgrade -y")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "Upgrading is finished"')
            os.system('echo')
        elif self.upgrade_aptitude_radio.isChecked():
            os.system("aptitude dist-upgrade")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "Upgrading is finished"')
            os.system('echo')
        
    def run_app_command(self):
        if self.apps_discover_radio.isChecked():
            os.system("plasma-discover")
            
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "discover package manager."')
            os.system('echo')
        elif self.apps_synaptic_radio.isChecked():
            os.system("synaptic")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "synaptic package manager."')
            os.system('echo')
        
    def run_updater_command(self):
        if self.updater_yes_radio.isChecked():
            os.system("sudo bash -c 'bash /opt/predator-os-updater/new-predator-os-changes.sh'")
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "predator-os is upgraded to last version"')
            os.system('echo')
        elif self.updater_no_radio.isChecked():
            
            os.system('echo')
            os.system('echo')
            os.system('tput setaf 3;echo "You rejected the Upgrading...."')
            os.system('echo')

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PredatorUpdaterApp()
    window.show()
    sys.exit(app.exec_())
