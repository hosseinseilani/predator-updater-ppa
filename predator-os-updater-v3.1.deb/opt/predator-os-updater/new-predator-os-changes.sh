#!/bin/bash

clear
tput setaf 2;echo ") ################## 1) Updating the predator-os#################"
sleep 1
echo
echo

sudo apt install nala -y

sudo nala update

echo
tput setaf 3;echo "##################finished####################"
echo
sleep 2


#It enables the use of repositories accessed via the HTTP Secure protocol (HTTPS), also known as HTTP over TLS. This secure transport ensures that package downloads are encrypted and authenticated.
tput setaf 2;echo "####### 2) Enable the HTTP Secure protocol (HTTPS), also known as HTTP over TLS.#######"
sudo nala install apt-transport-https
echo
echo
tput setaf 3;echo "##################finished ##################"
sleep 2
echo

#fix ssh error in termial

tput setaf 2;echo "##################3) Fixing SSH error in termial##################"
current_user=$(last | head -n 1 | awk '{print $1}')

mkdir /home/$current_user/.ssh
mkdir /home/root/.ssh

chmod 755 /home/$current_user/.ssh
chmod 755 /home/root/.ssh
echo
tput setaf 3;echo "##################finished##################"
sleep 2


# Install Visual Studio Code (VSCode), and it will add the source list for the next version.
tput setaf 2;echo "##################4) Install Visual Studio Code (VSCode)##################"

curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg
sudo install -o root -g root -m 644 microsoft.gpg /etc/apt/keyrings/microsoft-archive-keyring.gpg
sudo sh -c 'echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/microsoft-archive-keyring.gpg] https://packages.microsoft.com/repos/vscode stable main" > /etc/apt/sources.list.d/vscode.list'

#now, vscode will install
nala update
nala install code


if [ -f /usr/share/applications/code.desktop ]; then
    tput setaf 2;echo "##################Finished##################"
    sleep 2
else
    cp -rf /opt/predator-os-updater/code.desktop /usr/share/applications/
fi
echo
tput setaf 3;echo "################## Finished ##################"
sleep 2
echo


# enables offloading rendering tasks to the NVIDIA GPU.Render Offload allows you to selectively use the NVIDIA GPU for specific applications without switching the entire system.

tput setaf 2;echo "5) Enables offloading rendering tasks to the NVIDIA GPU.Render Offload for all users"

if ! grep -q "__NV_PRIME_RENDER_OFFLOAD=1" ~/.bashrc; then
    echo "__NV_PRIME_RENDER_OFFLOAD=1" >> ~/.bashrc
fi

if ! grep -q "__VK_LAYER_NV_optimus=NVIDIA_only" ~/.bashrc; then
    echo "__VK_LAYER_NV_optimus=NVIDIA_only" >> ~/.bashrc
fi

if ! grep -q "__GLX_VENDOR_LIBRARY_NAME=" ~/.bashrc; then
    echo "__GLX_VENDOR_LIBRARY_NAME=" >> ~/.bashrc
fi

source ~/.bashrc
source source /home/root/.bashrc


current_user=$(last | head -n 1 | awk '{print $1}')

if ! grep -q "__NV_PRIME_RENDER_OFFLOAD=1" /home/$current_user/.bashrc; then
    echo "__NV_PRIME_RENDER_OFFLOAD=1" >> /home/$current_user/.bashrc
fi

if ! grep -q "__VK_LAYER_NV_optimus=NVIDIA_only" /home/$current_user/.bashrc; then
    echo "__VK_LAYER_NV_optimus=NVIDIA_only" >> /home/$current_user/.bashrc
fi

if ! grep -q "__GLX_VENDOR_LIBRARY_NAME=" /home/$current_user/.bashrc; then
    echo "__GLX_VENDOR_LIBRARY_NAME=" >> /home/$current_user/.bashrc
fi
source /home/$current_user/.bashrc
echo
tput setaf 3;echo "################## Finished ##################"
sleep 2
echo



#update grub config for new kernel parameters

tput setaf 2;echo "6) Update grub config for new kernel parameters"

GRUB_FILE="/etc/default/grub"
PARAMS="retbleed=off amd_pstate.enable=1 amd-pstate=active numa=on"

if ! grep -q "retbleed=off" $GRUB_FILE; then
    sed -i "/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/\"$/ retbleed=off\"/" $GRUB_FILE
fi

if ! grep -q "amd_pstate.enable=0" $GRUB_FILE; then
    sudo sed -i 's/amd_pstate.enable=0/amd_pstate.enable=1/' $GRUB_FILE
fi

if ! grep -q "amd-pstate=active" $GRUB_FILE; then
    sed -i "/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/\"$/ amd-pstate=active\"/" $GRUB_FILE
fi

if ! grep -q "numa=on" $GRUB_FILE; then
    sed -i "/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/\"$/ numa=on\"/" $GRUB_FILE
fi

# Update grub after changes
sudo update-grub
sudo update-initramfs -uv
echo
tput setaf 3;echo "################## Finished ##################"
sleep 2
echo

#disable split lock mitigate to increase performance in  applications and games
tput setaf 2;echo "7) Increasing preformance tune"
cp -rf /opt/predator-os-updater/  /etc

if ! grep -q "kernel.split_lock_mitigate=0" /etc/sysctl.conf; then
    echo "kernel.split_lock_mitigate=0" | sudo tee -a /etc/sysctl.conf > /dev/null
fi
sysctl -p

tput setaf 3;echo "################## Finished ##################"
echo
sleep 2
echo

# Enable full preemption
tput setaf 2;echo "################## 8) Enable full preemption##################"


CONFIG_VALUES=(
"CONFIG_PREEMPT=y"
"CONFIG_HZ_1000=y"
"CONFIG_HZ=1000"
"CONFIG_IRQ_FORCED_THREADING=y"
"CONFIG_PREEMPT_VOLUNTARY=y"
"CONFIG_NO_HZ_FULL=y"
"CONFIG_RCU_NOCB_CPU=y"
"CONFIG_RCU_LAZY=y"
)

# Function to add config values to kernel config file
add_to_kernel_config() {
  for value in "${CONFIG_VALUES[@]}"; do
    if ! grep -q "$value" "$KERNEL_CONFIG"; then
      echo "Adding $value to $KERNEL_CONFIG"
      echo "$value" | sudo tee -a "$KERNEL_CONFIG"
    else
      echo "$value already set in $KERNEL_CONFIG"
    fi
  done
}
 

#updated the lookpicking tools(password lists)
tput setaf 2;echo "9) Updated the lookpicking tools(password lists)"

tput setaf 3;echo "################## Finished ##################"
echo
echo


tput setaf 4;echo "10) Installing Hiddify proxy tool"
echo


if [ -f /usr/share/applications/hiddify.desktop ]; then
    tput setaf 3;echo "################## Finished ##################"
    sleep 2
else
    
dpkg -i /opt/predator-os-updater/Hiddify.deb
apt -f install
cp -rf /opt/predator-os-updater/hiddify.desktop /usr/share/applications/
tput setaf 3;echo "################## Finished ##################"
sleep 2
echo


fi


tput setaf 4;echo "11) Updating new tools"
tput setaf 4;echo "shodan-rootkit-passwordlists-prettyrecon-SqlOnline-drwadb-cupp"
cp -rf /opt/Shodan-filters.desktop /usr/share/applications/
cp -rf /opt/Rootkits-Linux.desktop /usr/share/applications/
cp -rf /opt/passwordlist.desktop /usr/share/applications/
cp -rf /opt/prettyrecon.desktop /usr/share/applications/
cp -rf /opt/sql-online.desktop /usr/share/applications/
cp -rf /opt/drawdb.desktop /usr/share/applications/
cp -rf /opt/predator-os-updater/10no--check-valid-until /etc/apt/apt.conf.d/

if [ -f /usr/share/applications/Cupp.desktop ]; then
    tput setaf 3;echo "################## Finished ##################"
    sleep 2
else
    
dpkg -i /opt/predator-os-updater/Cupp.deb
apt -f install
cp -rf /opt/predator-os-updater/Cupp.desktop /usr/share/applications/
tput setaf 3;echo "################## Finished ##################"
sleep 2
echo


fi

tput setaf 3;echo "########## Finished upgrading to new version #######"
echo
geany /opt/predator-os-updater/change-log3.1.txt
