#!/bin/bash

clear
#current version
current_verison=$(cat /etc/predator-os-version.txt)

#the URL to check
url="https://github.com/hosseinseilani/predator-updater/blob/main/3.1"
last_version=$(basename "$url")


# Compare the strings
if [[ "$current_verison" == "$last_version" ]]; then
    
    kdialog --msgbox "the installed predator-OS is te last version"
else
    kdialog --msgbox "New version is available, run predator-updater command from terminal or application menu"

fi
