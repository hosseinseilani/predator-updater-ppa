#! /bin/bash

cd /opt/Downloaded-Password-Lists


allinone(){

	tput setaf 3;echo "Downloading password lists to /home/password-files/..."	
	sleep 2
	git clone https://github.com/danielmiessler/SecLists.git
	wget "https://raw.githubusercontent.com/digination/dirbuster-ng/master/wordlists/big.txt" dirbuster_big.txt 


	wget https://www.vertex42.com/Files/exclusive/password-list.xlsx

	echo
	tput setaf 3;echo "1,493,677,782 words."
	tput setaf 3;echo "4.2 GiB compressed. 15 GiB uncompressed."
	wget https://crackstation.net/files/crackstation.txt.gz 

	echo
	tput setaf 3;echo "There are about 64 million passwords in this list!"
	tput setaf 3;echo "247 MiB compressed. 684 MiB uncompressed."
	wget https://crackstation.net/files/crackstation-human-only.txt.gz
	echo
	tput setaf 3;echo "16 billion words / 28Gb 7zip / 220Gb uncompressed "
	wget http://bigpasswordlist.com/stuff/DicAss.v.1.0.7z
	echo
	echo
	tput setaf 3;echo "milion password list"
	git clone https://github.com/berandal666/Passwords.git
	echo

	tput setaf 3;echo "A collection of wordlists for many different usages. They are sorted by their content. Feel free to request to add new wordlists."
	git clone https://github.com/kkrypt0nn/Wordlists.git
	tput setaf 3;echo "3000 words"
	git clone https://github.com/Python-Fa/Password-List.git
	echo
	tput setaf 3;echo "Lists of common used passwords"
	git clone https://github.com/djprmf/common-password-list.git

	echo

	tput setaf 3;echo "Security PassList"
	git clone https://github.com/j3ers3/PassList.git
	echo
	tput setaf 3;echo "Collection of some common wordlists such as RDP password, user name list, ssh password wordlist for brute force."
	git clone https://github.com/jeanphorn/wordlist.git

	echo
	tput setaf 3;echo "A collection of passwords and wordlists commonly used for dictionary-attacks using a variety of password cracking tools such as aircrack-ng, hydra and hashcat."
	git clone https://github.com/kennyn510/wpa2-wordlists.git

	echo	
	tput setaf 3;echo "Leaked passwords. Passwords that were leaked or stolen from sites"
	wget http://downloads.skullsecurity.org/passwords/porn-unknown.txt.bz2
	wget http://downloads.skullsecurity.org/passwords/porn-unknown-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/singles.org.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/singles.org-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/carders.cc.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/carders.cc-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/tuscl.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/tuscl-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/alypaa.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/alypaa-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hotmail-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/faithwriters.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/faithwriters-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/elitehacker.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/elitehacker-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hak5.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hak5-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/rockyou.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/rockyou-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb-withmd5.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/myspace.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/myspace-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hotmail.txt.bz2
	tput setaf 3;echo "These are dictionaries of words (etc), not passwords. They may be useful for one reason or another."
	wget http://downloads.skullsecurity.org/passwords/porno.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/web-mutations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/file-locations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/fuzzing-strings.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpmyadmin-locations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/web-extensions.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/honeynet-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/honeynet.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/english.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/german.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/us_cities.txt.bz2

	tput setaf 3;echo "Facebook lists"
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-names-unique.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-names-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-f.last-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-f.last.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-first.l-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-first.l.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-firstnames-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-firstnames.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-lastnames-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-lastnames.txt.bz2


	tput setaf 3;echo "Bruteforce Database - Password dictionaries"
	wget https://github.com/duyet/bruteforce-database.git


	tput setaf 3;echo "This is a HTML representation of the Oracle default password list."
	wget -E -H -k -K -p http://www.petefinnigan.com/default/oracle_default_passwords.htm

	tput setaf 3;echo "Comma separated list of the Oracle default passwords and hashes."
	wget http://www.petefinnigan.com/default/oracle_default_passwords.csv

	tput setaf 3;echo "An SQL script that will insert all of the default password list into an Oracle (or other database!) table called OSP_ACCOUNTS. This is the database table used in Marcel-Jan's tool so this script can always be used to increase the list of default users you wish to check with that tool if this list gets increased"
	wget http://www.petefinnigan.com/default/oracle_default_passwords.sql

	tput setaf 3;echo "This is an MS Excel spreadsheet representation of the default password list. This is the same spreadsheet that is included with the default password checking tool archive."
	wget http://www.petefinnigan.com/default/oracle_default_passwords.xls

	tput setaf 3;echo "This is an Open Office 1.0 spreadsheet representation of the default password list. This is the same spreadsheet that is included with the default password checking tool archive."
	wget http://www.petefinnigan.com/default/oracle_default_passwords.sxc

	tput setaf 3;echo "Downloading all password lists is finished"	

}


onebyone(){

	tput setaf 3;echo "Downloading password list one by one is starting...."	


	fun2(){
	read -p "**** list2 download eff_large_wordlist ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget http://www.petefinnigan.com/default/oracle_default_passwords.sxc


	fun3
	else 
	fun3
	fi
	}





	fun3(){
	read -p "**** list3 download lists/big ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget "https://raw.githubusercontent.com/digination/dirbuster-ng/master/wordlists/big.txt"
	fun4
	else 
	fun4
	fi
	}






	fun4(){
	read -p "**** list4 download SecLists ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	git clone https://github.com/danielmiessler/SecLists.git 


	fun5
	else 
	fun5
	fi
	}




	fun5(){
	read -p "**** list5 download  english large_wordlist ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget https://downloads.skullsecurity.org/passwords/english.txt.bz2


	fun6
	else 
	fun6
	fi
	}



	fun6(){
	read -p "**** list6 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://www.petefinnigan.com/default/oracle_default_passwords.sql


	fun7
	else 
	fun7
	fi
	}

	fun7(){
	read -p "**** list7 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://www.petefinnigan.com/default/oracle_default_passwords.csv


	fun8
	else 
	fun8
	fi
	}

	fun8(){
	read -p "**** list8 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget https://downloads.skullsecurity.org/passwords/hotmail.txt.bz2


	fun9
	else 
	fun9
	fi
	}

	fun9(){
	read -p "**** list9 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://www.petefinnigan.com/default/oracle_default_passwords.xls


	fun10
	else 
	fun10
	fi
	}




	fun10(){
	read -p "**** list10 download exclusive/password-list ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget https://www.vertex42.com/Files/exclusive/password-list.xlsx



	fun11
	else 
	fun11
	fi
	}


	fun11(){
	tput setaf 3;echo "1,493,677,782 words."
	tput setaf 3;echo "4.2 GiB compressed. 15 GiB uncompressed."

	read -p "**** list11 download crackstation ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 


	wget https://crackstation.net/files/crackstation.txt.gz 

	fun12
	else 
	fun12
	fi
	}



	fun12(){
	tput setaf 3;echo "There are about 64 million passwords in this list!"
	tput setaf 3;echo "247 MiB compressed. 684 MiB uncompressed."

	read -p "**** list12 download crackstation ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget https://crackstation.net/files/crackstation-human-only.txt.gz


	fun13
	else 
	fun13
	fi
	}


	fun13(){
	tput setaf 3;echo "16 billion words / 28Gb 7zip / 220Gb uncompressed "

	read -p "**** list13 download DicAss ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://bigpasswordlist.com/stuff/DicAss.v.1.0.7z


	fun14
	else 
	fun14
	fi
	}


	fun14(){
	tput setaf 3;echo "milion password list"

	read -p "**** list14 download Passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 


	git clone https://github.com/berandal666/Passwords.git

	fun15
	else 
	fun15
	fi
	}



	fun15(){
	tput setaf 3;echo "A collection of wordlists for many different usages. They are sorted by their content. Feel free to request to add new wordlists."

	read -p "**** list15 download Wordlists ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	git clone https://github.com/kkrypt0nn/Wordlists.git


	fun16
	else 
	fun16
	fi
	}

	fun16(){
	tput setaf 3;echo "3000 words"

	read -p "**** list16 download Password-List ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	git clone https://github.com/Python-Fa/Password-List.git


	fun17
	else 
	fun17
	fi
	}


	fun17(){
	tput setaf 3;echo "Lists of common used passwords"

	read -p "**** list17 download common-password-list ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	git clone https://github.com/djprmf/common-password-list.git



	fun18
	else 
	fun18
	fi
	}




	fun18(){
	tput setaf 3;echo "Security PassList"

	read -p "**** list18 download PassList ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	git clone https://github.com/j3ers3/PassList.git


	fun19
	else 
	fun19
	fi
	}


	fun19(){
	tput setaf 3;echo "Collection of some common wordlists such as RDP password, user name list, ssh password wordlist for brute force."

	read -p "**** list19 download wordlist ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	git clone https://github.com/jeanphorn/wordlist.git



	fun20
	else 
	fun20
	fi
	}



	fun20(){
	tput setaf 3;echo "A collection of passwords and wordlists commonly used for dictionary-attacks using a variety of password cracking tools such as aircrack-ng, hydra and hashcat."

	read -p "**** list20 download wpa2-wordlists ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	git clone https://github.com/kennyn510/wpa2-wordlists.git


	fun21
	else 
	fun21
	fi
	}




	fun21(){
	tput setaf 3;echo "Leaked passwords. Passwords that were leaked or stolen from sites"

	read -p "**** list21 download unknown ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://downloads.skullsecurity.org/passwords/porn-unknown.txt.bz2
	wget http://downloads.skullsecurity.org/passwords/porn-unknown-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/singles.org.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/singles.org-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/carders.cc.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/carders.cc-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/tuscl.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/tuscl-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/alypaa.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/alypaa-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hotmail-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/faithwriters.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/faithwriters-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/elitehacker.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/elitehacker-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hak5.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/hak5-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/rockyou.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/rockyou-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpbb-withmd5.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/myspace.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/myspace-withcount.txt.bz2

	fun22
	else 
	fun22
	fi
	}


	fun22(){
	read -p "**** list22 download web,fuzzing,phpmyadmin,honeynet and ...??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget http://downloads.skullsecurity.org/passwords/porno.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/web-mutations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/file-locations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/fuzzing-strings.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/phpmyadmin-locations.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/web-extensions.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/honeynet-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/honeynet.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/german.txt.bz2

	fun23
	else 
	fun23
	fi
	}

	fun23(){
	read -p "**** list23 download facebook ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-pastebay.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-phished.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-names-unique.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-names-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-f.last-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-f.last.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-first.l-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-first.l.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-firstnames-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-firstnames.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-lastnames-withcount.txt.bz2
	wget https://downloads.skullsecurity.org/passwords/facebook-lastnames.txt.bz2

	fun24
	else 
	fun24
	fi
	}



	fun24(){
	read -p "**** list24 download bruteforce ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 

	wget https://github.com/duyet/bruteforce-database.git


	fun25
	else 
	fun25
	fi
	}




	fun25(){
	tput setaf 3;echo "This is a HTML representation of the Oracle default password list."

	read -p "**** list25 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget http://www.petefinnigan.com/default/oracle_default_passwords.htm



	fun26
	else 
	fun26
	fi
	}


	fun26(){

	tput setaf 3;echo "This is an aggregate archive of malware backdoor passwords as uncovered by the Malvuln project."
	read -p "**** list26 download Viruscreds Malware Password Database ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	
	wget https://dl.packetstormsecurity.net/Crackers/wordlists/viruscreds-main.zip

	echo 
	echo "All checked, come back to first password list."
	fun27
	else 
	fun27	

	fun1
	fi
	}



	fun28(){
	tput setaf 3;echo "This is a wordlist of 518 star names to be used for cracking."

	read -p "**** list25 download Star Names Wordlist ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget https://packetstormsecurity.com/files/download/160987/star-names.txt

	fun29
	else 
	fun29
	fi
	}




	fun29(){
	tput setaf 3;echo "This is a HTML representation of the Oracle default password list."

	read -p "**** list25 download oracle_default_passwords ??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget http://www.petefinnigan.com/default/oracle_default_passwords.htm



	fun30
	else 
	fun30
	fi
	}



	fun30(){
	tput setaf 3;echo "This file contains two wordlists with both male and female Arabic names. Together there are over 1800 entries."

	read -p "**** list25 download Arabic Names Dictionary??  y/n: " confirm
	echo
	if [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]]  
	then 
	wget https://dl.packetstormsecurity.net/Crackers/wordlists/names/arabicnames.zip


	fun1
	else 
	fun
	fi
	}



	fun1
	fun2
	fun2
	fun3
	fun4
	fun5
	fun6
	fun7
	fun8
	fun9
	fun10
	fun11
	fun12
	fun13
	fun14
	fun15
	fun16
	fun17
	fun18
	fun19
	fun20
	fun21
	fun22
	fun23
	fun24
	fun25
	fun26
	fun27
	fun28
	fun29
	fun30


	}




	main(){


	if [ -d "/opt/passwordlists/" ] 
	then



	tput setaf 3;echo ""
	tput setaf 3 bold;echo "============== password list Downloader ============"
	tput setaf 3;echo ""


	tput setaf 3;echo "Defualt Directory for downloading passwords is passwordlists in /opt directory." 
	tput setaf 3;echo "Delete the  /opt/passwordlists/   folder and starting it again."
	tput setaf 3;echo 
	tput setaf 3;echo "or"
	echo
	tput setaf 3; echo "========================="
	tput setaf 3;echo "type new path for download the lists:"
	read -p "Continue? (Y)- Exit(N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1
	newpath=$(zenity --entry --text 'Please type the path:') || exit 1
	cd $newpath
	mkdir passwordlists

	cd /opt/passwordlists
	read -p "all in one  (y) or one by one (n):" ans 
	if [[ $ans == [yY] || $confirm == [yY][eE][sS] ]]
	then
	allinone
	else
	onebyone
	fi


	else
	echo "creating /opt/passwordlists/ ."
	mkdir /opt/passwordlists
	cd /opt/passwordlists

	tput setaf 3;echo "All downloading finished..."

	fi

}

main
